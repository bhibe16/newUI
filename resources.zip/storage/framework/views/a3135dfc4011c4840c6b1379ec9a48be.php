<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="logout-url" content="<?php echo e(route('logout')); ?>">
    <title>HRIS - Job Listings</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
</head>
<body class="main-content min-h-screen">
    <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="flex">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="flex-grow p-16">
            <div class="container mx-auto p-6">
                <h2 class="text-2xl font-bold mb-4">Job Listings</h2>
                <div id="cardLayout" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
                    <?php $__currentLoopData = $jobPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex flex-col items-center mb-8 bg-white p-6 rounded-lg cursor-pointer hover:shadow-sm transition min-h-[300px] w-50 relative" 
                            onclick="toggleModal('modal-<?php echo e($job['id']); ?>')">
                            
                            <h3 class="text-lg font-bold mb-2"><?php echo e($job['title']); ?></h3>
                            <p class="text-gray-500 text-center"><?php echo e($job['location']); ?></p>
                            <p class="text-gray-500 mb-4 text-center"><?php echo e($job['department']); ?></p>
                            
                            <div class="flex flex-col items-start w-full space-y-3 rounded-sm p-5 bg-gray-100">
                                <div class="flex items-center space-x-2">
                                    <label class="text-sm font-medium">Salary:</label>
                                    <p class="text-sm text-gray-700">₱<?php echo e(number_format($job['salary'])); ?></p>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="text-sm font-medium">Schedule:</label>
                                    <p class="text-sm text-gray-700"><?php echo e($job['schedule']); ?></p>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="text-sm font-medium">Created At:</label>
                                    <p class="text-sm text-gray-700"><?php echo e(\Carbon\Carbon::parse($job['created_at'])->format('m/d/Y')); ?></p>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <label class="text-sm font-medium">Updated At:</label>
                                    <p class="text-sm text-gray-700"><?php echo e(\Carbon\Carbon::parse($job['updated_at'])->format('m/d/Y')); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </main>
    </div>

    <!-- Modal -->
    <?php $__currentLoopData = $jobPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="modal-<?php echo e($job['id']); ?>" class="fixed inset-0 bg-gray-900 bg-opacity-50 flex items-center justify-center hidden">
        <div class="bg-white rounded-lg shadow-lg p-6 max-w-lg w-full">
            <h2 class="text-2xl font-semibold mb-4"><?php echo e($job['title']); ?></h2>
            <p class="text-gray-700 mb-4"><?php echo e($job['description']); ?></p>
            <div class="border-t pt-4 text-sm text-gray-600">
                <p><strong>Created At:</strong> <?php echo e(\Carbon\Carbon::parse($job['created_at'])->format('M d, Y h:i A')); ?></p>
                <p><strong>Updated At:</strong> <?php echo e(\Carbon\Carbon::parse($job['updated_at'])->format('M d, Y h:i A')); ?></p>
            </div>
            <button onclick="toggleModal('modal-<?php echo e($job['id']); ?>')" class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 mt-4">Close</button>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script>
        function toggleModal(modalId) {
            let modal = document.getElementById(modalId);
            if (modal.classList.contains('hidden')) {
                modal.classList.remove('hidden');
            } else {
                modal.classList.add('hidden');
            }
        }
    </script>
</body>
</html>
<?php /**PATH C:\wamp64\www\hris-me--main\resources\views/admin/jobpost/index.blade.php ENDPATH**/ ?>