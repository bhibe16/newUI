<nav x-data="{ open: false, showAdminNotifications: false, showEmployeeNotifications: false, showChat: false }" class="linear-gradient">
    <!-- Primary Navigation Menu -->
    <div class="max-w-10xl mx-auto px-4 sm:px-6 lg:px-7">
        <div class="flex justify-between h-16">
            <!-- Logo -->
            <div class="flex items-center" style="margin-left: 2cm;">
    <div class="shrink-0">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo" class="w-12 h-12">
    </div>
</div>

            <!-- Chat, Notification, and Settings -->
            <div class="hidden sm:flex sm:items-center sm:ms-6 space-x-4">
                <!-- Chat Icon -->
                <div class="relative">
                    <button @click="showChat = !showChat" class="relative p-2 text-gray-500 hover:text-gray-700 focus:outline-none">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                        </svg>
                    </button>
                    <div x-show="showChat" @click.outside="showChat = false" class="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg overflow-hidden">
                        <div class="p-2 text-sm text-gray-700">Chat</div>
                        <ul class="divide-y divide-gray-200">
                            <li class="p-2 hover:bg-gray-100">Chat with Support</li>
                            <li class="p-2 hover:bg-gray-100">Chat with Team</li>
                        </ul>
                        <a href="<?php echo e(route('admin.notifications')); ?>" class="block text-center text-blue-600 hover:underline p-2" @click.stop>
    View all
</a>
                    </div>
                </div>

                <?php if(Auth::user()->role == 'admin' || Auth::user()->role == 'hr3'): ?>
               <!-- Admin Notification Icon -->
<div class="relative">
    <button @click="showAdminNotifications = !showAdminNotifications" class="relative p-2 text-gray-500 hover:text-gray-700 focus:outline-none">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14V11a6.002 6.002 0 00-4-5.659V4a2 2 0 10-4 0v1.341C7.67 6.165 6 8.388 6 11v3a2.032 2.032 0 01-.595 1.405L4 17h5m6 0a3 3 0 11-6 0m6 0H9"></path>
        </svg>
        <?php if(Auth::user()->unreadNotifications->count() > 0): ?>
            <span class="absolute top-0 right-0 inline-flex items-center justify-center px-1 py-0.5 text-xs font-bold leading-none text-white bg-red-500 rounded-full">
                <?php echo e(Auth::user()->unreadNotifications->count()); ?>

            </span>
        <?php endif; ?>
    </button>
    <div x-show="showAdminNotifications" @click.outside="showAdminNotifications = false" class="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg">
        <div class="p-2 text-sm text-gray-700 border-b">Admin Notifications</div>
        <div class="max-h-36 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
            <ul class="divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = Auth::user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="p-2 hover:bg-gray-100">
                    <a href="<?php echo e($notification->data['url']); ?>" onclick="markNotificationAsRead('<?php echo e($notification->id); ?>')" class="block text-sm">
                        <?php echo e($notification->data['message']); ?>

                    </a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="p-2 text-gray-500 text-sm">No new notifications</li>
                <?php endif; ?>
            </ul>
        </div>
        <a href="<?php echo e(route('admin.notifications')); ?>" class="block text-center text-blue-600 hover:underline p-2 border-t">View all</a>
    </div>
</div>
                <?php elseif(Auth::user()->role == 'Employee'): ?>
                <!-- Notification Icon for Employee -->
                <div class="relative">
                    <!-- Notification Bell Icon -->
                    <button @click="showEmployeeNotifications = !showEmployeeNotifications" class="relative p-2 text-gray-500 hover:text-gray-700 focus:outline-none">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14V11a6.002 6.002 0 00-4-5.659V4a2 2 0 10-4 0v1.341C7.67 6.165 6 11 6 11v3a2.032 2.032 0 01-.595 1.405L4 17h5m6 0a3 3 0 11-6 0m6 0H9"></path>
                        </svg>

                        <!-- Notification Badge -->
                        <?php
                            $notificationCount = Auth::user()->unreadNotifications->count();
                        ?>
                        <?php if($notificationCount > 0): ?>
                            <span class="absolute top-0 right-0 inline-flex items-center justify-center px-1 py-0.5 text-xs font-bold leading-none text-white bg-red-500 rounded-full">
                                <?php echo e($notificationCount); ?>

                            </span>
                        <?php endif; ?>
                    </button>

                    <!-- Notification Dropdown -->
                    <div x-show="showEmployeeNotifications" @click.outside="showEmployeeNotifications = false" class="absolute right-0 mt-2 w-72 bg-white rounded-lg shadow-lg overflow-hidden border border-gray-200">
                        <div class="p-3 text-sm font-semibold text-gray-800 bg-gray-100">Notifications</div>

                        <ul class="divide-y divide-gray-200 max-h-64 overflow-auto">
                            <!-- Laravel Notifications -->
                            <?php $__currentLoopData = Auth::user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="p-3 hover:bg-gray-100">
                                    <p class="text-sm text-gray-700"><?php echo e($notification->data['message']); ?></p>
                                    <?php if($notification->data['status'] == 'rejected'): ?>
                                        <p class="text-xs text-red-500">Reason: <?php echo e($notification->data['rejection_comment']); ?></p>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <!-- Static Employee Notifications -->
                            <li class="p-3 hover:bg-gray-100 text-gray-700">New company policy update</li>
                            <li class="p-3 hover:bg-gray-100 text-gray-700">Upcoming team meeting</li>
                        </ul>

                        <!-- View All Notifications Link -->
                        <a href="#" class="block text-center text-blue-600 hover:underline p-3 text-sm font-medium">View all</a>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Display Time -->
                <div class="text-gray-700">
                    <span id="current-time"></span>
                </div>

                <!-- Settings Dropdown for Both Admin and Employee -->
                <?php if (isset($component)) { $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown','data' => ['align' => 'right','width' => '48']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>
                     <?php $__env->slot('trigger', null, []); ?> 
                        <button class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition ease-in-out duration-150">
                            <div><?php echo e(Auth::user()->name); ?></div>
                            <div class="ms-1">
                                <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a 1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </button>
                     <?php $__env->endSlot(); ?>

                     <?php $__env->slot('content', null, []); ?> 
                        <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('profile.edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('profile.edit'))]); ?>
                            <?php echo e(__('Setting')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault(); this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault(); this.closest(\'form\').submit();']); ?>
                                <?php echo e(__('Log Out')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                        </form>
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $attributes = $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $component = $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
</nav>
<script>
    function markNotificationAsRead(notificationId) {
        fetch(`/notifications/${notificationId}/mark-as-read`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                'Content-Type': 'application/json'
            },
        });
    }

    function updateTime() {
        const timeElement = document.getElementById('current-time');
        const now = new Date();
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');
        timeElement.innerText = `${hours}:${minutes}:${seconds}`;
    }

    setInterval(updateTime, 1000); // Update time every second
</script><?php /**PATH C:\wamp64\www\hris-me--main\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>